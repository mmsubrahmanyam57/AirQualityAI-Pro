from flask import Flask, render_template, request, jsonify, Response
from pollution_model import simulate
import csv,io
app=Flask(__name__)
def result():
    return simulate(float(request.args.get('speed',14)),float(request.args.get('direction',0)),float(request.args.get('emission',70)),int(request.args.get('source',0)))
@app.route('/')
def index():return render_template('index.html')
@app.route('/api/simulate')
def api():
    try:return jsonify(result())
    except (ValueError,IndexError,OverflowError):return jsonify(error='Invalid simulation settings'),400
@app.route('/report.csv')
def report():
    try: rows=result()['sensors']
    except (ValueError,IndexError,OverflowError):return 'Invalid settings',400
    f=io.StringIO(); w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)
    return Response(f.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=demo-sensor-report.csv'})
if __name__=='__main__':app.run(port=5000)
